#ifndef XICON_H
#define XICON_H

extern ALLEGRO_BITMAP *_al_xwin_initial_icon;

#endif // XICON_H
